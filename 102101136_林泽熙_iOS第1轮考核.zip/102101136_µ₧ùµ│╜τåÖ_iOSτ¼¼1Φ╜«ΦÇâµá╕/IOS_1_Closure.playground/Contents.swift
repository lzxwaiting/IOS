import ClassKit

func Maker(x:Int)->Void{
    print(x)
    if(x <= 2022){
        param(x + Int.random(in: 1...10))
    }else{
        param(nil)
    }
}
let param = {(x:Int?) -> Void in
    if(x == nil){
        print("error")
    }else{
        let Area:Double = 3.14 * Double(x!) * Double(x!)
        print("Area: ", Area)
    }
}
//let a:Int = (getline()!)!
//还没弄懂如何从Console里面读入用户所给的值
/*
Maker(2055)
Maker(2)
Maker(2021)
*/
