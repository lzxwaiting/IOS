import UIKit
//Ans 1
func avg(scores:[Int])->Double{
    var sum=0.0
    for score in scores{
        sum += Double(score)
    }
    let totalNum=Double(scores.count)
    return sum/totalNum
}
func max(nums:[Int])->Int{
    var maxN=nums[0]
    for num in nums {
        if(num>maxN){
            maxN=num
        }
    }
    return maxN
}
var scores:[Int] = [78,66,98,53,82,90,78,69]

func avgAndMaxNum(scores:[Int]) -> (Double,Int){
    return (avg(scores: scores),max(nums:scores))
}

var average=avg(scores: scores)
var maxNum=max(nums: scores)
let result:(Double,Int)=avgAndMaxNum(scores:scores)
/*print(average)
print(maxNum)
print(result)
*/

//Ans2
func leapYear(year:Int)->Bool{
    if((year%4 == 0 && year%100 != 0)||year%400 == 0  ){
        return true
    }else{
        return false
    }
}
/*
let judge:Bool = leapYear(year:year)
if (judge == true){
    print("\(year) is a leap year")
}else{
    print("\(year) is not a leap year")
}
*/


//Ans3
func myPow(_ x: Double, _ n: Int) -> Double {
    // 特殊处理 0 1 -1 可以直接 return 结果
    if x == 0 || x == 1 {
        return x
    }
    else if x == -1 {
        return (n & 1 == 1 ? -1 : 1)
    }
    
    if n == 0 {
        return 1
    }
    
    var ans: Double = 1
    var power = abs(n)
    var newX = x
    while power > 0 {
        if power & 1 == 1 {
            ans *= newX
        }
        newX *= newX
        power = power >> 1
    }
    return n < 0 ? 1 / ans : ans
}

func millerRabin(n:Int)->Bool {
    var j = 0
    if (n == 2){
        return true
    }
    if (n < 3 || n % 2 == 0){
        return false
    }
    var a = n - 1;var b = 0;
    while (a % 2 == 0){
        a /= 2
        b += 1
    }
    //print(a,b)
  //  var i:Int64 = 0
  // test_time 为测试次数,建议设为不小于 8
  // 的整数以保证正确率,但也不宜过大,否则会影响效率
    for _ in(1...3) {
    var x = Int.random(in: 1...n-1) % (n - 2) + 2
        var v:Int = Int(myPow(Double(x), a))
    print(v)
        j = 0
        if (v == 1) {
            continue;
        }
        for _ in (1...b) {
            j += 1
            if (v == n - 1){
                break;
            }
            v = v * v % n;
    }
        if (j >= b){
            return false;
            
        }
  }
  return true;
}
//var aa:Bool = millerRabin(n:97)

